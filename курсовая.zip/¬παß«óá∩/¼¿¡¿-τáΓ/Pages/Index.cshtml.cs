using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;

public class IndexModel : PageModel
{
    [BindProperty]
    public string? Nickname { get; set; }

    [BindProperty]
    public string? Message { get; set; }

    public List<ChatMessage> Messages { get; set; } = new List<ChatMessage>();

    public class ChatMessage
    {
        public string Sender { get; set; } = "";
        public string Text { get; set; } = "";
        public DateTime Timestamp { get; set; }
        public bool IsSystem { get; set; }
    }

    // список сообщений для всех
    private static List<ChatMessage> _allMessages = new List<ChatMessage>();

    public void OnGet()
    {
        Messages = _allMessages;

        if (string.IsNullOrEmpty(HttpContext.Session.GetString("Nickname")))
        {
            ViewData["ShowNicknameModal"] = true;
        }
        else
        {
            ViewData["ShowNicknameModal"] = false;
            ViewData["UserNickname"] = HttpContext.Session.GetString("Nickname");
        }
    }

    public IActionResult OnPostSetNickname()
    {
        if (!string.IsNullOrEmpty(Nickname) && Nickname.Length >= 2 && Nickname.Length <= 20)
        {
            HttpContext.Session.SetString("Nickname", Nickname);

            _allMessages.Add(new ChatMessage
            {
                Sender = "System",
                Text = $"{Nickname} join the chat",
                Timestamp = DateTime.Now,
                IsSystem = true
            });
        }

        return RedirectToPage();
    }

    public IActionResult OnPostSendMessage()
    {
        var nickname = HttpContext.Session.GetString("Nickname");

        if (!string.IsNullOrEmpty(Message) && !string.IsNullOrEmpty(nickname))
        {
            _allMessages.Add(new ChatMessage
            {
                Sender = nickname,
                Text = Message,
                Timestamp = DateTime.Now,
                IsSystem = false
            });

            Message = ""; 
        }

        return RedirectToPage();
    }
}